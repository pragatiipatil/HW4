
import java.util.Arrays;

public class Question2 {
	public static void main(String[] args) {
		String s = "pragatiipatil";
		char[] ch = s.toCharArray();
		Arrays.sort(ch);
		String result = "";
		for(int i = 0; i < ch.length-1; i ++)
		{
			if(ch[i] == ch[i+1])
			{
				result += ch[i];
			}
			
		}
				
		 System.out.println("duplicates present in the string are: " + result)
		 ;
		
	}
	

} 

