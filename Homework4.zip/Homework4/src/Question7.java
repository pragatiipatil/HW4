import java.util.Arrays;

public class Question7 {

	public static void main(String[] args) {
		
		String s = "Saroja";
		s = s.toLowerCase();
		String flag = "";
		char[] c = s.toCharArray();
		Arrays.sort(c);
		int countMax = 0;
		char max_occu;
		for(int i = 0; i < c.length-1; i++)
		{
			int count = 0;
			while(c[i] == c[i+1])
			{
				count++;
				System.out.println("Contains duplicate characters");
				break;
			}
			
			if(count > countMax)
			{
				countMax = count;
				max_occu = c[i];
			}
						
		}
		
		if(countMax == 0)
		{
			System.out.println("No duplicates");
		}
			
		
	}

}
