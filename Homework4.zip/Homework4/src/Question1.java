import java.util.Arrays;

public class Question1 {
	public static void main(String[] args) {
		String s = "babablackship";
		char[] ch = s.toCharArray();
		Arrays.sort(ch);
		String result = "";
		for(int i = 0; i < ch.length-1; i ++)
		{
			if(ch[i] == ch[i+1])
			{
				continue;
			}
			else
			{
				result += ch[i];
			}
		}
		
		result += ch[ch.length-1];
		
		 System.out.println("String after removing duplicates: " + result)
		 ;
		
	}
	

} 
