
public class Question3 {

	   public static void main(String[] args) {
	        String s = "110011";
	        s = s.toLowerCase();
	        int i = 0;
	        int j = s.length()-1;
	        int mid = (i+j)/2;
	        for(int c = 0; c <= mid; c ++)
	        {
	            if(s.charAt(i) == s.charAt(j))
	            {
	                j--;
	                i++;
	            }
	            else
	            {
	                System.out.println("not a palindrome");
	                break;
	            }

	        }

	        if(i == mid+1)
	            System.out.println("It is a palindrome!");



	    }

}
