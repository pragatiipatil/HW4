
import java.util.Arrays;

public class Question8 {

	public static void main(String[] args) {
		
		String s = "pragati";
		s = s.toLowerCase();
		String flag = "";
		char[] c = s.toCharArray();
		Arrays.sort(c);
		int countMax = 0;
		char max_occu = '\u0000';
		for(int i = 0; i < c.length-1; i++)
		{
			int j = i;
			int count = 0;
			while(c[i]==c[i+1])
			{
				count++;
				i++;	
			}
			
			if(count > countMax)
			{
				countMax = count;
				max_occu = c[i];
			}
						
		}
		
		if(countMax == 0)
		{
			System.out.println("No duplicates");
		}
		else
		{
			System.out.println("Maximum occuring character is: " 
		+ max_occu);
		}
	
			
		
	}

}
