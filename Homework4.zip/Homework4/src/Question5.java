import java.util.Arrays;

public class Question5 {

	public static void main(String[] args) 
	{		
		String s1 = "1234Chacha!";
		String s2 = "Chacha!123412";
		s1 = s1.toLowerCase();
		s2 = s2.toLowerCase();
		char[] ch1 = s1.toCharArray();
		char[] ch2 = s2.toCharArray();
		Arrays.sort(ch1);
		Arrays.sort(ch2);
		boolean flag = true;
		if(ch1.length != ch2.length)
		{
			System.out.println("Not an Anagram!");
			flag = false;
		}
		else
		{
			for(int i = 0; i < ch1.length; i ++)
			{
				if(ch1[i] != ch2[i])
					{
						System.out.println("Not an Anagram");
						flag = false;
						break;
					}

			}
		}
		
		if(flag== true)
			System.out.println("Anagram!");
		
		
	}

}
