
public class Question4 {

	public static void main(String[] args) {
		
		String s = "AbcdAeiOu@#!123";
		int vow = 0;
		int cons = 0;
		int others = 0;
		
		for(int i = 0; i < s.length(); i ++)
		{
			if(s.charAt(i) == 'A' || s.charAt(i) == 'E' || s.charAt(i) == 'I' || s.charAt(i) == 'O' || s.charAt(i) == 'U'
					|| s.charAt(i) == 'a' || s.charAt(i) == 'e' || s.charAt(i) == 'i' || s.charAt(i) == 'o' || s.charAt(i) == 'u')
			{
				vow++;
			}
			else if((s.charAt(i) > 64 && s.charAt(i) <= 90) ||( s.charAt(i) > 96 && s.charAt(i) <= 122))
			{
				cons++;
			}
			else
				others++;
			
		}
		
		System.out.println("Number of Vowels: " + vow);
		System.out.println("Number of Consonants: " + cons);
		System.out.println("Number of special characters: " + others);

	}

}
